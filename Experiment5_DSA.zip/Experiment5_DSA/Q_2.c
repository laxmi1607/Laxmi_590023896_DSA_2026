/* 2.	Write a C program to create a binary tree using linked list representation and 
erform various operations on it.
(i)	Insert nodes into the tree (use user input).
(ii)	Create separate functions to count.
•	Total number of nodes.
•	Number of leaf nodes (nodes with no children).
•	Height of the binary tree. */

#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *left, *right;
};

struct Node* createNode(int value) {
    struct Node* newNode = (struct Node*)malloc(sizeof(struct Node));
    newNode->data = value;
    newNode->left = newNode->right = NULL;
    return newNode; 
}

struct Node* insert(struct Node* root, int value) {
    if (root == NULL)
        return createNode(value);

    if (value < root->data)
        root->left = insert(root->left, value);
    else
        root->right = insert(root->right, value);

    return root;
}

int totalNodes(struct Node* root) {
    if (root == NULL) return 0;
    return 1 + totalNodes(root->left) + totalNodes(root->right);
}

int leafNodes(struct Node* root) {
    if (root == NULL) return 0;
    if (root->left == NULL && root->right == NULL) return 1;
    return leafNodes(root->left) + leafNodes(root->right);
}

int height(struct Node* root) {
    if (root == NULL) return 0;
    int left = height(root->left);
    int right = height(root->right);
    return (left > right ? left : right) + 1;
}

int main() {
    struct Node* root = NULL;

    root = insert(root, 10);
    root = insert(root, 5);
    root = insert(root, 15);

    printf("Total Nodes: %d\n", totalNodes(root));
    printf("Leaf Nodes: %d\n", leafNodes(root));
    printf("Height: %d\n", height(root));

    return 0;
}