/* 1.	Write a C program to create a binary tree using an array. The program should 
support the following operations: 
(i)	Insert elements into the tree.
(ii)	Display the tree elements.
(iii)	Display the parent, left child, and right child of a given node. */

#include <stdio.h>

#define MAX 100

int tree[MAX];
int size = 0;

void insert(int value) {
    if (size == MAX) {
        printf("Tree Overflow\n");
        return;
    }
    tree[size++] = value;
}

void display() {
    if (size == 0) {
        printf("Tree is empty\n");
        return;
    }
    for (int i = 0; i < size; i++)
        printf("%d ", tree[i]);
    printf("\n");
}

void findRelations(int index) {
    if (index >= size) {
        printf("Invalid index\n");
        return;
    }

    printf("Node: %d\n", tree[index]);

    if (index == 0)
        printf("Parent: None\n");
    else
        printf("Parent: %d\n", tree[(index - 1) / 2]);

    if (2 * index + 1 < size)
        printf("Left Child: %d\n", tree[2 * index + 1]);
    else
        printf("Left Child: None\n");

    if (2 * index + 2 < size)
        printf("Right Child: %d\n", tree[2 * index + 2]);
    else
        printf("Right Child: None\n");
}

int main() {
    insert(10);
    insert(20);
    insert(30);
    insert(40);

    display();
    findRelations(1);

    return 0;
}