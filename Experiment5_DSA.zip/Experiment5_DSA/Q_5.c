/* 5.	Write a C program to implement non-recursive tree traversals of a binary tree using
 a stack. Your program should implement the following traversals using the stack:
(i)	Inorder traversal (Left → Root → Right).
(ii)	Preorder traversal (Root → Left → Right). */

#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *left, *right;
};

struct node* create(int data) {
    struct node* newnode = (struct node*)malloc(sizeof(struct node));
    newnode->data = data;
    newnode->left = newnode->right = NULL;
    return newnode;
}

struct node* stack[100];
int top = -1;

void push(struct node* x) {
    stack[++top] = x;
}

struct node* pop() {
    return stack[top--];
}

void inorder(struct node* root) {
    struct node* current = root;

    top = -1;  // reset stack

    while (current != NULL || top != -1) {
        while (current != NULL) {
            push(current);
            current = current->left;
        }

        current = pop();
        printf("%d ", current->data);

        current = current->right;
    }
}

void preorder(struct node* root) {
    if (root == NULL) return;

    top = -1;  // reset stack
    push(root);

    while (top != -1) {
        struct node* temp = pop();
        printf("%d ", temp->data);

        if (temp->right != NULL)
            push(temp->right);

        if (temp->left != NULL)
            push(temp->left);
    }
}

int main() {
    struct node* root = create(1);
    root->left = create(2);
    root->right = create(3);
    root->left->left = create(4);
    root->left->right = create(5);

    printf("Inorder: ");
    inorder(root);

    printf("\nPreorder: ");
    preorder(root);

    return 0;
}