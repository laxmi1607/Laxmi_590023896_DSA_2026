/* Write a C program to perform Level Order Traversal on a binary tree using a queue.*/

#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *left, *right;
};

struct node* create(int data) {
    struct node* newnode = (struct node*)malloc(sizeof(struct node));
    newnode->data = data;
    newnode->left = newnode->right = NULL;
    return newnode;
}

struct node* queue[100];
int front = -1, rear = -1;

void enqueue(struct node* x) {
    if (rear == 99) return;
    if (front == -1) front = 0;
    queue[++rear] = x;
}

struct node* dequeue() {
    if (front == -1 || front > rear) return NULL;
    return queue[front++];
}

void levelorder(struct node* root) {
    if (root == NULL) return;

    enqueue(root);

    while (front <= rear) {
        struct node* temp = dequeue();
        printf("%d ", temp->data);

        if (temp->left != NULL)
            enqueue(temp->left);

        if (temp->right != NULL)
            enqueue(temp->right);
    }
}

int main() {
    struct node* root = create(1);
    root->left = create(2);
    root->right = create(3);
    root->left->left = create(4);
    root->left->right = create(5);

    printf("Level Order Traversal: ");
    levelorder(root);

    return 0;
}