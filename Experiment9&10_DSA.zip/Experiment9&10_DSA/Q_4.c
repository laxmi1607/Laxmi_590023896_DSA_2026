/* Write a C program to implement the Merge Sort using recursion.
(i)	Input: An array of n integers.
(ii) Output: Sorted array in ascending order.
(iii) Requirements:
•	Clearly implement the divide and merge steps. */

#include <stdio.h>

void merge(int arr[], int low, int mid, int high)
{
    int temp[100];
    int i=low, j=mid+1, k=low;

    while(i<=mid && j<=high)
    {
        if(arr[i] < arr[j])
            temp[k++] = arr[i++];
        else
            temp[k++] = arr[j++];
    }

    while(i<=mid)
        temp[k++] = arr[i++];

    while(j<=high)
        temp[k++] = arr[j++];

    for(i=low;i<=high;i++)
        arr[i]=temp[i];
}

void mergeSort(int arr[], int low, int high)
{
    int mid;

    if(low<high)
    {
        mid=(low+high)/2;

        mergeSort(arr,low,mid);
        mergeSort(arr,mid+1,high);

        merge(arr,low,mid,high);
    }
}

int main()
{
    int n,i;

    printf("Enter size of array: ");
    scanf("%d",&n);

    int arr[n];

    printf("Enter elements:\n");
    for(i=0;i<n;i++)
        scanf("%d",&arr[i]);

    mergeSort(arr,0,n-1);

    printf("Sorted Array: ");

    for(i=0;i<n;i++)
        printf("%d ",arr[i]);

    return 0;
}