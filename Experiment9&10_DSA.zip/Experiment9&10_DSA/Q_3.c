/* Write a C program to implement the Insertion Sort algorithm.
(i)	Input: An array of n integers.
(ii) Output: Sorted array in ascending order.
(iii) Requirements:
•	Display the array after inserting each element. */

#include <stdio.h>

void printArray(int arr[], int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d ",arr[i]);
    printf("\n");
}

int main()
{
    int n,i,j,key;

    printf("Enter size of array: ");
    scanf("%d",&n);

    int arr[n];

    printf("Enter elements:\n");
    for(i=0;i<n;i++)
        scanf("%d",&arr[i]);

    for(i=1;i<n;i++)
    {
        key=arr[i];
        j=i-1;

        while(j>=0 && arr[j]>key)
        {
            arr[j+1]=arr[j];
            j--;
        }

        arr[j+1]=key;

        printf("After inserting element %d: ",i);
        printArray(arr,n);
    }

    printf("\nSorted Array: ");
    printArray(arr,n);

    return 0;
}