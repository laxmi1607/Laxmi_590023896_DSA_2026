/* Write a C program to implement Binary Search using recursion.
(i)	Input a sorted array and a key value.
(ii) Use a recursive function to perform the search.
(iii) Return and display the index of the element if found. */

#include <stdio.h>

int binarySearch(int arr[], int low, int high, int key)
{
    int mid;

    if(low<=high)
    {
        mid=(low+high)/2;

        if(arr[mid]==key)
            return mid;

        if(key < arr[mid])
            return binarySearch(arr,low,mid-1,key);

        return binarySearch(arr,mid+1,high,key);
    }

    return -1;
}

int main()
{
    int n,i,key,result;

    printf("Enter size of array: ");
    scanf("%d",&n);

    int arr[n];

    printf("Enter sorted elements:\n");
    for(i=0;i<n;i++)
        scanf("%d",&arr[i]);

    printf("Enter element to search: ");
    scanf("%d",&key);

    result = binarySearch(arr,0,n-1,key);

    if(result==-1)
        printf("Element not found");
    else
        printf("Element found at index %d",result);

    return 0;
}