/* Write a C program to implement the Quick Sort using recursion.
(i)	Input: An array of n integers.
(ii) Output: Sorted array in ascending order.
(iii) Requirements:
•	Use any partitioning scheme. */

#include <stdio.h>

int partition(int arr[], int low, int high)
{
    int pivot = arr[low];
    int i = low+1;
    int j = high;
    int temp;

    while(i<=j)
    {
        while(arr[i] <= pivot && i<=high)
            i++;

        while(arr[j] > pivot)
            j--;

        if(i<j)
        {
            temp=arr[i];
            arr[i]=arr[j];
            arr[j]=temp;
        }
    }

    temp=arr[low];
    arr[low]=arr[j];
    arr[j]=temp;

    return j;
}

void quickSort(int arr[], int low, int high)
{
    int p;

    if(low<high)
    {
        p = partition(arr,low,high);

        quickSort(arr,low,p-1);
        quickSort(arr,p+1,high);
    }
}

int main()
{
    int n,i;

    printf("Enter size of array: ");
    scanf("%d",&n);

    int arr[n];

    printf("Enter elements:\n");
    for(i=0;i<n;i++)
        scanf("%d",&arr[i]);

    quickSort(arr,0,n-1);

    printf("Sorted Array: ");

    for(i=0;i<n;i++)
        printf("%d ",arr[i]);

    return 0;
}