/* Write a C program to implement the Selection Sort algorithm.
(i)	Input: An array of n integers.
(ii)	Output: Sorted array in ascending order.
(iii)	Requirements:
•	Display the array after each pass.
•	Count and display the total number of comparisons and swaps. */

#include <stdio.h>

void printArray(int arr[], int n)
{
    int i;
    for(i=0;i<n;i++)
        printf("%d ",arr[i]);
    printf("\n");
}

int main()
{
    int n,i,j,min,temp;
    int comparisons=0, swaps=0;

    printf("Enter size of array: ");
    scanf("%d",&n);

    int arr[n];

    printf("Enter elements:\n");
    for(i=0;i<n;i++)
        scanf("%d",&arr[i]);

    for(i=0;i<n-1;i++)
    {
        min=i;

        for(j=i+1;j<n;j++)
        {
            comparisons++;

            if(arr[j] < arr[min])
                min=j;
        }

        if(min!=i)
        {
            temp=arr[i];
            arr[i]=arr[min];
            arr[min]=temp;
            swaps++;
        }

        printf("After Pass %d: ",i+1);
        printArray(arr,n);
    }

    printf("\nSorted Array: ");
    printArray(arr,n);

    printf("Total Comparisons = %d\n",comparisons);
    printf("Total Swaps = %d\n",swaps);

    return 0;
}