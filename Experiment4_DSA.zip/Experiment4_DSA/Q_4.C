/* Write a C program to implement a Circular Queue using an array of fixed size using the 
following functions for each operation.
(i)	Insert (Enqueue): Add an element to the Circular Queue.
(ii)	Delete (Dequeue): Remove an element from the Circular Queue.
(iii)	 Display: Display all elements of the Circular Queue. */

#include <stdio.h>

int cq[5];
int front = -1, rear = -1, size = 5;

void enqueue(int x) {
    if ((rear + 1) % size == front) {
        printf("Overflow\n");
        return;
    }
    if (front == -1) front = 0;
    rear = (rear + 1) % size;
    cq[rear] = x;
}

void dequeue() {
    if (front == -1) {
        printf("Underflow\n");
        return;
    }
    printf("Deleted: %d\n", cq[front]);
    if (front == rear)
        front = rear = -1;
    else
        front = (front + 1) % size;
}

void display() {
    if (front == -1) {
        printf("Empty\n");
        return;
    }
    int i = front;
    while (1) {
        printf("%d ", cq[i]);
        if (i == rear) break;
        i = (i + 1) % size;
    }
    printf("\n");
}

int main() {
    enqueue(1);
    enqueue(2);
    enqueue(3);
    display();
    dequeue();
    display();
}