/* Write a program to check whether a given string is a palindrome or not using an Array and 
a Queue data structure.*/

#include <stdio.h>
#include <string.h>

int main() {
    char str[100];
    printf("Enter string: ");
    scanf("%s", str);

    int i = 0, j = strlen(str) - 1;
    int flag = 1;

    while (i < j) {
        if (str[i] != str[j]) {
            flag = 0;
            break;
        }
        i++;
        j--;
    }

    if (flag)
        printf("Palindrome\n");
    else
        printf("Not Palindrome\n");
}