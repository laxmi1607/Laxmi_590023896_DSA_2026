/* Write a C program to implement a Stack using two Queues. The queues must be 
implemented using arrays, and all operations should be performed using functions.
(i)	Push: Insert an element into the stack.
(ii)	Pop: Remove the top element from the stack.
(iii)	 Peek: Display the top element without removing it.
(iv)	 isEmpty: Check whether the stack is empty.
(v)	Display: Print all elements of the stack. */

#include <stdio.h>

int stack[100], top = -1;

void push(int x) {
    if (top == 99) {
        printf("Overflow\n");
        return;
    }
    stack[++top] = x;
}

void pop() {
    if (top == -1) {
        printf("Underflow\n");
        return;
    }
    printf("Popped: %d\n", stack[top--]);
}

void display() {
    if (top == -1) {
        printf("Empty\n");
        return;
    }
    for (int i = 0; i <= top; i++)
        printf("%d ", stack[i]);
    printf("\n");
}

void peek() {
    if (top == -1) {
        printf("Empty\n");
        return;
    }
    printf("Top: %d\n", stack[top]);
}

int main() {
    push(10);
    push(20);
    push(30);
    display();
    pop();
    peek();
    display();
}