/* Write a C program to implement a Queue data structure using an array. 
The program should be modular and use separate functions for each operation.
(i)	Insert (Enqueue): Add an element to the Queue.
(ii)	Delete (Dequeue): Remove an element from the Queue.
(iii)	Display: Display all elements of the Queue.
(iv)	Peek: Display the front element of the Queue. */

/*1. Write a C program to implement a Queue data structure using array*/
#include <stdio.h>

int queue[100], front = -1, rear = -1;

void enqueue(int x) {
    if (rear == 99) {
        printf("Queue Overflow\n");
        return;
    }
    if (front == -1) front = 0;
    queue[++rear] = x;
}

void dequeue() {
    if (front == -1 || front > rear) {
        printf("Queue Underflow\n");
        return;
    }
    printf("Deleted: %d\n", queue[front++]);
}

void display() {
    if (front == -1 || front > rear) {
        printf("Queue Empty\n");
        return;
    }
    for (int i = front; i <= rear; i++)
        printf("%d ", queue[i]);
    printf("\n");
}

void peek() {
    if (front == -1 || front > rear) {
        printf("Queue Empty\n");
        return;
    }
    printf("Front element: %d\n", queue[front]);
}

int main() {
    enqueue(10);
    enqueue(20);
    enqueue(30);
    display();
    dequeue();
    peek();
    display();
}