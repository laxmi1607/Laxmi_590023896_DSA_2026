/* Write a C program to implement a Binary Search Tree (BST) using a linked list 
representation. Your program should support the following operations:
(i)	Insertion: Insert a node into the BST while maintaining BST properties. Duplicate 
values should not be allowed.
(ii) Deletion: Delete a node from the BST based on a given key.
• Handle all three cases: (a) Node is a leaf node, (b) Node has one child and 
(c) Node has two children
(iii)	 Searching: Search for a given value in the BST (Display whether the element is 
found or not).
(iv)	 Traversal: In order Traversal (Left → Root → Right). */


#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node *left, *right;
};

struct node* create(int val) {
    struct node* temp = (struct node*)malloc(sizeof(struct node));
    temp->data = val;
    temp->left = temp->right = NULL;
    return temp;
}

struct node* insert(struct node* root, int val) {
    if (root == NULL)
        return create(val);

    if (val < root->data)
        root->left = insert(root->left, val);
    else if (val > root->data)
        root->right = insert(root->right, val);
    else
        printf("Duplicate not allowed!\n");

    return root;
}

struct node* findMin(struct node* root) {
    while (root->left != NULL)
        root = root->left;
    return root;
}

struct node* deleteNode(struct node* root, int key) {
    if (root == NULL) return root;

    if (key < root->data)
        root->left = deleteNode(root->left, key);
    else if (key > root->data)
        root->right = deleteNode(root->right, key);
    else {
        if (root->left == NULL && root->right == NULL)
            return NULL;
        else if (root->left == NULL)
            return root->right;
        else if (root->right == NULL)
            return root->left;

        struct node* temp = findMin(root->right);
        root->data = temp->data;
        root->right = deleteNode(root->right, temp->data);
    }
    return root;
}

void search(struct node* root, int key) {
    if (root == NULL)
        printf("Not Found\n");
    else if (key == root->data)
        printf("Found\n");
    else if (key < root->data)
        search(root->left, key);
    else
        search(root->right, key);
}

void inorder(struct node* root) {
    if (root != NULL) {
        inorder(root->left);
        printf("%d ", root->data);
        inorder(root->right);
    }
}

int main() {
    struct node* root = NULL;
    int choice, val;

    while (1) {
        printf("\n1.Insert 2.Delete 3.Search 4.Display 5.Exit\n");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                printf("Enter value: ");
                scanf("%d", &val);
                root = insert(root, val);
                break;

            case 2:
                printf("Enter value to delete: ");
                scanf("%d", &val);
                root = deleteNode(root, val);
                break;

            case 3:
                printf("Enter value to search: ");
                scanf("%d", &val);
                search(root, val);
                break;

            case 4:
                printf("Inorder: ");
                inorder(root);
                break;

            case 5:
                exit(0);
        }
    }
}